'use strict';
// node test/uave.test.js – prüft lib/uave.js gegen einen nachgebauten UAV Editor (kein Internet nötig)
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { makeCtx } = require('../lib/ctx');

// ---------- kleines ZIP bauen (Methode 8 bzw. 0) ----------
function crc32(buf) { let c, crc = 0xFFFFFFFF; for (let n = 0; n < buf.length; n++) { c = (crc ^ buf[n]) & 0xFF; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; crc = (crc >>> 8) ^ c; } return (crc ^ 0xFFFFFFFF) >>> 0; }
function makeZip(files) {
  const parts = [], central = []; let off = 0;
  for (const [name, content, store] of files) {
    const data = Buffer.from(content), comp = store ? data : zlib.deflateRawSync(data), nb = Buffer.from(name);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(store ? 0 : 8, 8);
    lh.writeUInt32LE(crc32(data), 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26);
    parts.push(lh, nb, comp);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(store ? 0 : 8, 10);
    ch.writeUInt32LE(crc32(data), 16); ch.writeUInt32LE(comp.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nb.length, 28); ch.writeUInt32LE(off, 42);
    central.push(ch, nb); off += 30 + nb.length + comp.length;
  }
  const cd = Buffer.concat(central), e = Buffer.alloc(22);
  e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(files.length, 8); e.writeUInt16LE(files.length, 10); e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, e]);
}
function encPoly(pts) { let out = '', pa = 0, pb = 0; const enc = v => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 0x20) { s += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return s + String.fromCharCode(v + 63); };
  for (const [a, b] of pts) { const ia = Math.round(a * 1e5), ib = Math.round(b * 1e5); out += enc(ia - pa) + enc(ib - pb); pa = ia; pb = ib; } return out; }

const TEMPLATE = '<?xml version="1.0"?><kml><Document><wpml:globalHeight>70</wpml:globalHeight><Placemark><Polygon><coordinates>8.1,50.4 8.2,50.4 8.2,50.5</coordinates></Polygon></Placemark></Document></kml>';
const KMZ = makeZip([['wpmz/template.kml', TEMPLATE], ['wpmz/waylines.wpml', '<wpml/>', true]]);

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kr-uave-'));
  const events = [];
  const ctx = makeCtx(path.join(dir, 'data'), code => events.push(code));
  ctx.api = { isOnline: async () => true };
  ctx._uaveDelay = 5;
  const calls = [];
  const ring = [[50.40, 8.10], [50.40, 8.20], [50.50, 8.20], [50.40, 8.10]];
  ctx.fetch = async (url, opts) => {
    const h = opts.headers || {};
    calls.push({ url, method: opts.method, h });
    const json = o => new Response(JSON.stringify(o), { status: 200, headers: { 'content-type': 'application/json' } });
    if (url.endsWith('/graphql')) {
      assert.strictEqual(h.Origin, 'https://app.uaveditor.com'); assert.strictEqual(h.app, 'uav'); assert.strictEqual(h.lang, 'de');
      const b = JSON.parse(opts.body);
      if (b.query.includes('auth(app')) return json(b.variables.password === 'geheim' ? { data: { auth: { token: 'TOK', id: 'u1' } } } : { errors: [{ message: 'falsches Passwort' }] });
      const authed = h.authorization === 'Bearer TOK';   // nur die dritte Variante funktioniert
      if (b.query.includes('getFields(')) {
        if (!authed) return json({ errors: [{ message: 'nicht angemeldet' }] });
        const fields = b.variables.archive
          ? [{ id: 'A1', name: 'Müller Wiese', copterProfile: 'dji-pilot-2', lastModified: '2026-10-20T10:00:00.000Z', createdAt: '2026-10-19T08:30:00.000Z', area: 3.2, flightTime: 600, orderData: { cuttingDate: '2026-05-01' } },
             { id: 'X9', name: 'Andere', copterProfile: 'dji-pilot', createdAt: '2026-01-01T00:00:00.000Z' }]
          : [{ id: 'B2', name: 'Schmidt 2026', copterProfile: 'dji-pilot-2', lastModified: '2026-10-26T10:00:00Z', createdAt: '2026-10-26T09:00:00Z', area: 1.5, flightTime: 300, orderData: null }];
        return json({ data: { getFields: { count: fields.length, fields } }, extensions: { auth: { id: 'u1' } } });
      }
      if (b.query.includes('getFieldsMapData')) {
        assert.ok(authed);
        if (!b.variables.fieldsFilter.archived) return json({ data: { getFieldsMapData: { fields: [] } } });
        return json({ data: { getFieldsMapData: { fields: [{ _id: 'A1', name: 'Müller Wiese', polygonLineString: encPoly(ring), lineString: encPoly(ring),
          missionSettings: { djiPilot2: { droneType: 'M4T', height: 70 } }, planningInfos: [{ planningName: '2026' }], contributor: { firstname: 'Max', name: 'Muster' }, center: [8.15, 50.45] }] } } });
      }
      if (b.query.includes('bulkPatchFieldSettings')) return json({ data: { bulkPatchFieldSettings: [{ id: 'A1' }] } });
    }
    if (url.endsWith('/export') && opts.method === 'POST') {
      const form = new URLSearchParams(opts.body);
      assert.strictEqual(form.get('token'), 'TOK'); assert.strictEqual(JSON.parse(form.get('items'))[0].outputs[0].format, 'kml-pilot-2');
      return new Response("<script>var exportStateId = 'S1';</script>", { status: 200 });
    }
    if (url.includes('/export-state/S1')) return json({ status: 'ready', downloadUrl: '/download-export/S1' });
    if (url.endsWith('/download-export/S1')) return new Response(KMZ, { status: 200, headers: { 'content-disposition': 'attachment; filename="Muller Wiese_3,20ha_12WP.kmz"' } });
    return new Response('nicht gefunden', { status: 404 });
  };
  const U = require('../lib/uave')(ctx);
  const lastEvent = name => { for (let i = events.length - 1; i >= 0; i--) { const m = new RegExp('window\\.' + name + '\\(("(?:[^"\\\\]|\\\\.)*")\\)').exec(events[i]); if (m) return JSON.parse(JSON.parse(m[1])); } return null; };
  const waitFor = async (pred, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { const r = pred(); if (r) return r; await new Promise(r => setTimeout(r, 10)); } throw new Error('Zeitüberschreitung'); };

  // Zugang
  assert.strictEqual(U.uaveHasPassword(), false);
  U.uaveSetCredentials('  max@example.org ', 'falsch');
  assert.strictEqual(U.uaveUser(), 'max@example.org');
  assert.ok(U.uaveHasPassword());
  assert.ok(!String(ctx.prefs.get('uave_pw')).includes('falsch'), 'Passwort verschlüsselt');
  U.uaveTest();
  let t = await waitFor(() => lastEvent('onUaveTest'));
  assert.strictEqual(t.ok, false); assert.ok(/fehlgeschlagen: falsches Passwort/.test(t.error));
  U.uaveSetCredentials('max@example.org', 'geheim');
  events.length = 0; U.uaveTest();
  t = await waitFor(() => lastEvent('onUaveTest')); assert.strictEqual(t.ok, true);

  // Katalog-Abgleich
  const src = path.join(dir, 'src'); fs.mkdirSync(src);
  fs.writeFileSync(path.join(src, 'schmidt_2026_1,50ha_5WP.kmz'), KMZ);   // liegt schon da → „ok“ über Namen
  events.length = 0; U.uaveCheck(src);
  const list = await waitFor(() => { const e = lastEvent('onUave'); return e && (e.type === 'list' || e.type === 'error') ? e : null; });
  assert.strictEqual(list.type, 'list', JSON.stringify(list));
  assert.strictEqual(list.total, 2); assert.strictEqual(list.missing, 1);
  const a1 = list.fields.find(f => f.id === 'A1'), b2 = list.fields.find(f => f.id === 'B2');
  assert.strictEqual(a1.status, 'missing'); assert.strictEqual(a1.arch, true); assert.strictEqual(a1.cut, '2026-05-01');
  assert.strictEqual(a1.created, '2026-10-19T08:30:00.000Z'); assert.strictEqual(a1.createdMs, Date.parse('2026-10-19T08:30:00.000Z'));
  assert.strictEqual(a1.mod, Date.parse('2026-10-20T10:00:00.000Z'));
  assert.strictEqual(a1.meta.dt, 'M4T'); assert.strictEqual(a1.meta.h, 70); assert.deepStrictEqual(a1.meta.years, ['2026']); assert.strictEqual(a1.meta.by, 'Max Muster');
  assert.deepStrictEqual(a1.meta.r.slice(0, 2), [8.1, 50.4], 'Kontur als Länge, Breite');
  assert.strictEqual(b2.status, 'ok'); assert.strictEqual(b2.file, 'schmidt_2026_1,50ha_5WP.kmz'); assert.strictEqual(b2.cut, '');
  const cat = JSON.parse(U.uaveCatalog()); assert.strictEqual(cat.fields.length, 2); assert.ok(cat.t > 0);
  assert.ok(events.some(e => e.includes('Lade Feldliste')), 'Statusmeldungen');
  assert.ok(calls.filter(c => c.url.endsWith('/graphql')).some(c => c.h.authorization === 'Bearer TOK'));
  const ol = JSON.parse(U.uaveOutlines()); assert.strictEqual(ol._all.length, 1); assert.strictEqual(ol._all[0].n, 'Müller Wiese');
  assert.strictEqual(JSON.parse(U.uaveFieldMeta())['schmidt_2026_1,50ha_5WP.kmz'].id, 'B2');

  // Download (einzeln)
  events.length = 0; U.uaveDownload('["A1"]', src, '-60');
  const done = await waitFor(() => { const e = lastEvent('onUave'); return e && (e.type === 'done' || e.type === 'error') ? e : null; });
  assert.strictEqual(done.type, 'done', JSON.stringify(done)); assert.strictEqual(done.ok, 1); assert.deepStrictEqual(done.errors, []);
  assert.strictEqual(done.files.A1, 'Muller Wiese_3,20ha_12WP.kmz');
  assert.ok(fs.existsSync(path.join(src, done.files.A1)));
  assert.ok(events.some(e => e.includes('progress')));
  assert.strictEqual(JSON.parse(U.uaveFieldMeta())['Muller Wiese_3,20ha_12WP.kmz'].cut, '2026-05-01');

  // Dateien
  const lk = JSON.parse(U.listKmz(src)); assert.ok(lk.ok); assert.strictEqual(lk.files.length, 2); assert.ok(lk.files[0].size > 0 && lk.files[0].mtime > 0);
  assert.ok(!JSON.parse(U.listKmz(path.join(dir, 'gibtsnicht'))).ok);
  const kml = U.readKml(path.join(src, done.files.A1)); assert.ok(kml.includes('<wpml:globalHeight>70'), 'template.kml aus KMZ');
  const noCoord = makeZip([['wpmz/template.kml', '<kml><Document/></kml>'], ['wpmz/waylines.wpml', '<coordinates>8,50</coordinates>']]);
  fs.writeFileSync(path.join(dir, 'nc.kmz'), noCoord); assert.ok(U.readKml(path.join(dir, 'nc.kmz')).includes('<!--SPLIT-->'));
  const deep = path.join(dir, 'rc'); fs.mkdirSync(path.join(deep, 'ID1', 'wpmz'), { recursive: true }); fs.writeFileSync(path.join(deep, 'ID1', 'wpmz', 'template.kml'), TEMPLATE);
  const ld = JSON.parse(U.listKmzDeep(deep)); assert.strictEqual(ld.files[0].name, 'ID1.kml'); assert.strictEqual(ld.files[0].rcId, 'ID1');
  const dst = path.join(dir, 'import');
  assert.strictEqual(U.ensureDir(dst), true); assert.ok(fs.existsSync(dst));
  const srcFile = path.join(src, done.files.A1);
  const tr = JSON.parse(U.transfer(JSON.stringify([srcFile, path.join(src, 'weg.kmz')]), dst, false, true, 'M4T'));
  assert.strictEqual(tr.done, 1); assert.strictEqual(tr.errors.length, 1); assert.strictEqual(tr.names[srcFile], done.files.A1);
  assert.ok(fs.existsSync(path.join(dst, done.files.A1)) && fs.existsSync(srcFile));
  assert.strictEqual(U._decodePolyline(encPoly([[50.123, 8.456]]))[0][0], 50.123);

  // Vergessen
  U.uaveForget(); assert.strictEqual(U.uaveUser(), ''); assert.strictEqual(U.uaveHasPassword(), false);
  console.log('uave: alle Tests bestanden');
  fs.rmSync(dir, { recursive: true, force: true });
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
