'use strict';
/* Test für lib/osm.js – ohne Internet: ctx.fetch liefert vorbereitete Antworten. Aufruf: node desktop/test/osm.test.js */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { makeCtx } = require('../lib/ctx');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kr-osm-'));
const events = [];
const ctx = makeCtx(dir, code => events.push(code));
ctx.sleep = async () => { };
ctx.api = { isOnline: async () => true };
const calls = [];

// ---------- vorbereitete Antworten ----------
const OBS = { elements: [
  { type: 'way', id: 1001, tags: { power: 'line', voltage: '110000;20000', operator: 'Westnetz', name: 'Limburg–Diez', ref: 'L12', cables: '6', frequency: '50', circuits: '2' },
    geometry: [{ lat: 50.3801234, lon: 8.0601234 }, { lat: 50.3900001, lon: 8.0700009 }] },
  { type: 'way', id: 1002, tags: { power: 'minor_line', operator: 'Syna' }, geometry: [{ lat: 50.37, lon: 8.05 }, { lat: 50.371, lon: 8.051 }] },
  { type: 'way', id: 1003, tags: { power: 'cable', voltage: '20000' }, geometry: [{ lat: 50.36, lon: 8.04 }, { lat: 50.361, lon: 8.041 }] },   // Erdkabel: nicht in osmLines
  { type: 'way', id: 1004, tags: { power: 'line', voltage: 'unknown' }, geometry: [{ lat: 50.35, lon: 8.03 }] },                             // nur 1 Punkt: weg
  { type: 'node', id: 2001, lat: 50.38, lon: 8.06, tags: { power: 'tower', height: '42 m', ref: 'M17', operator: 'Westnetz' } },
  { type: 'node', id: 2002, lat: 50.381, lon: 8.061, tags: { power: 'tower' } },                                                             // ohne Höhe: kein Hindernis-Punkt
  { type: 'node', id: 3001, lat: 50.40, lon: 8.10, tags: { power: 'generator', 'generator:source': 'wind', 'generator:hub_height': '141', 'rotor:diameter': '116,8', name: 'E6 Elz' } },
  { type: 'way', id: 3002, tags: { power: 'generator', 'generator:source': 'wind', height: '150' }, geometry: [{ lat: 50.41, lon: 8.11 }, { lat: 50.412, lon: 8.112 }] },
  { type: 'node', id: 4001, lat: 50.42, lon: 8.12, tags: { man_made: 'communications_tower', height: '120', operator: 'Telekom' } },
  { type: 'way', id: 5001, tags: { railway: 'rail', electrified: 'contact_line', name: 'Lahntalbahn' }, geometry: [{ lat: 50.385, lon: 8.065 }, { lat: 50.386, lon: 8.066 }] },
  { type: 'node', id: 6001, lat: 50.3833, lon: 8.0667, tags: { place: 'town', name: 'Limburg an der Lahn' } }
] };
const WAYS = { elements: [
  { type: 'way', id: 7001, tags: { highway: 'track', tracktype: 'grade2' }, geometry: [{ lat: 50.385, lon: 8.065 }, { lat: 50.39, lon: 8.07 }] },
  { type: 'way', id: 7002, tags: { highway: 'path' }, geometry: [{ lat: 51.0, lon: 9.0 }, { lat: 51.001, lon: 9.001 }] }
] };
const AF = { elements: [
  { type: 'way', id: 8001, center: { lat: 50.4166, lon: 8.0103 }, tags: { aeroway: 'aerodrome', name: 'Flugplatz Elz', icao: 'EDFZ' } },
  { type: 'node', id: 8002, lat: 50.4170, lon: 8.0110, tags: { aeroway: 'helipad' } },                                    // auf dem Flugplatz: doppelt → weg
  { type: 'node', id: 8003, lat: 50.3880, lon: 8.0750, tags: { emergency: 'landing_site', name: 'RTH Landestelle St. Vincenz' } },
  { type: 'node', id: 8004, lat: 50.14542, lon: 8.71011, tags: { aeroway: 'heliport', name: 'Uniklinik Frankfurt' } }        // an Christoph 2 → aufgewertet
] };
const FREQ = 'id,airport_ref,airport_ident,type,description,frequency_mhz\n1,2,"EDFZ","INFO","Elz Info","122.000"\n3,4,"EDDF","TWR","Frankfurt Tower","119.900"\n';
const MASTR = { Total: 2, Data: [
  { Breitengrad: 50.41, Laengengrad: 8.0, BetriebsStatusName: 'In Betrieb', NabenhoeheWindenergieanlage: 141, RotordurchmesserWindenergieanlage: 116.8, AnlagenbetreiberPersonenArt: 518,
    AnlagenbetreiberName: 'Max Mustermann', WindparkName: 'Elzer Berg', EinheitName: 'E6', Ort: 'Elz', MaStRNummer: 'SEE1', Id: 4711, Nettonennleistung: 3000 },
  { Breitengrad: 50.42, Laengengrad: 8.01, BetriebsStatusName: 'In Planung', NabenhoeheWindenergieanlage: 160 }
] };
const DULV_LIST = '<table><tr><td>EDFZ</td><td><a href="details.php?id=11">Elz</a></td><td>UL</td><td>65604</td></tr>'
  + '<tr><td>LOXX</td><td><a href="details.php?id=12">Wien</a></td><td>UL</td><td>A-1010</td></tr></table>';
const DULV_DET = '<table><tr><td>Ortskennung:</td><td>Elz-Malmeneich</td></tr><tr><td>Nord:</td><td>50.25.00 N</td></tr><tr><td>Ost:</td><td>8.00.36 E</td></tr>'
  + '<tr><td>Funk:</td><td>Elz Info 122,000</td></tr><tr><td>Betriebszeiten:</td><td>nach PPR&nbsp;\u0096 Fl&auml;che</td></tr></table>';

function resp(status, body, type) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body), 'utf8');
  return { status, ok: status >= 200 && status < 300, headers: { get: k => (k.toLowerCase() === 'content-type' ? type || 'application/json' : null) },
    text: async () => buf.toString('utf8'), json: async () => JSON.parse(buf.toString('utf8')), arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length) };
}
let overpassFailFirst = true;
ctx.fetch = async (url, opts = {}) => {
  const q = opts.body ? decodeURIComponent(String(opts.body).replace(/^data=/, '')) : '';
  calls.push(url + (q ? ' ' + q.slice(0, 60) : ''));
  if (/interpreter/.test(url)) {
    if (overpassFailFirst && /^https:\/\/overpass-api\.de/.test(url)) { overpassFailFirst = false; return resp(504, 'busy'); }   // erster Server überlastet → Wiederholung
    if (/highway/.test(q)) return resp(200, WAYS);
    if (/aeroway/.test(q)) return resp(200, AF);
    if (/around:/.test(q)) return resp(200, { elements: [{ type: 'way', id: 9, tags: { power: 'line' } }] });
    if (/place/.test(q) && !/power/.test(q)) return resp(200, { elements: [{ type: 'node', id: 6001, lat: 50.38331234, lon: 8.06671234, tags: { place: 'town', name: 'Limburg an der Lahn' } }] });
    return resp(200, OBS);
  }
  if (/airport-frequencies/.test(url)) return resp(200, FREQ, 'text/csv');
  if (/open-meteo/.test(url)) { const n = new URL(url).searchParams.get('latitude').split(',').length; return resp(200, { elevation: Array(n).fill(117.6) }); }
  if (/marktstammdatenregister/.test(url)) return resp(200, MASTR);
  if (/show_all\.php/.test(url)) return resp(200, Buffer.from(DULV_LIST, 'latin1'), 'text/html; charset=ISO-8859-1');
  if (/details\.php/.test(url)) return resp(200, Buffer.from(DULV_DET, 'latin1'), 'text/html; charset=ISO-8859-1');
  throw Object.assign(new TypeError('fetch failed'), { cause: { code: 'ENOTFOUND' } });
};

const osm = require('../lib/osm.js')(ctx);
const toLatLon = flat => { const o = []; for (let i = 0; i + 1 < flat.length; i += 2) o.push([flat[i + 1], flat[i]]); return o; };   // aus index.html
const had = name => events.some(e => e.includes(name));

(async () => {
  const box = [50.45, 50.35, 8.15, 8.0];
  // ---------- Leitungen & Hindernisse ----------
  assert.strictEqual(osm.osmLines(), '[]', 'ohne Daten leer');
  await osm._osmSync(...box, false);
  assert.ok(had('onOsmLines'), 'onOsmLines gemeldet');
  assert.ok(fs.existsSync(path.join(dir, 'osm_power.json')) && fs.existsSync(path.join(dir, 'osm_ways.json')), 'Dateien geschrieben');
  assert.strictEqual(JSON.parse(ctx.prefs.get('osm_bbox')).n, 50.45);
  assert.strictEqual(ctx.prefs.get('osm_ver'), 7);
  assert.ok(ctx.catStatus.hindernisse === 'ok' && ctx.catStatus.feldwege === 'ok', 'Status ok: ' + JSON.stringify(ctx.catStatus));
  const lines = JSON.parse(osm.osmLines());
  assert.strictEqual(lines.length, 2, 'nur line/minor_line mit ≥2 Punkten');
  const l = lines.find(x => x.id === 1001);
  assert.deepStrictEqual(Object.keys(l).sort(), ['c', 'ci', 'f', 'g', 'id', 'kv', 'loc', 'n', 'o', 'p', 'r', 't'].sort());
  assert.strictEqual(l.kv, 110); assert.strictEqual(l.o, 'Westnetz'); assert.strictEqual(l.n, 'Limburg–Diez'); assert.strictEqual(l.r, 'L12');
  assert.deepStrictEqual(l.g, [8.06012, 50.38012, 8.07, 50.39]);
  assert.deepStrictEqual(toLatLon(l.g)[0], [50.38012, 8.06012], 'index.html toLatLon liest es');
  assert.strictEqual(lines.find(x => x.id === 1002).n, '', 'ohne Name/Ref leer');

  const ob = JSON.parse(osm.osmObstacles());
  assert.deepStrictEqual(Object.keys(ob).sort(), ['places', 'pts', 'rails']);
  const pm = ob.pts.find(p => p.t === 'pmast');
  assert.deepStrictEqual(pm, { t: 'pmast', h: 42, n: 'M17', op: 'Westnetz', lat: 50.38, lon: 8.06 });
  assert.strictEqual(ob.pts.filter(p => p.t === 'pmast').length, 1, 'Mast ohne Höhe fehlt');
  const wn = ob.pts.find(p => p.t === 'wind' && p.n === 'E6 Elz');
  assert.strictEqual(wn.hub, 141); assert.strictEqual(wn.rot, 116.8); assert.strictEqual(wn.h, 0);
  const ww = ob.pts.find(p => p.t === 'wind' && p.h === 150);
  assert.ok(Math.abs(ww.lat - 50.411) < 1e-9 && Math.abs(ww.lon - 8.111) < 1e-9, 'Windrad als Fläche: Mittelpunkt');
  assert.deepStrictEqual(ob.pts.find(p => p.t === 'tower'), { t: 'tower', h: 120, hub: 0, rot: 0, n: 'Telekom', lat: 50.42, lon: 8.12 });
  assert.deepStrictEqual(ob.rails, [{ e: true, n: 'Lahntalbahn', g: [8.065, 50.385, 8.066, 50.386] }]);
  assert.deepStrictEqual(ob.places, [{ n: 'Limburg an der Lahn', t: 'town', lat: 50.3833, lon: 8.0667 }]);

  const ways = JSON.parse(osm.osmWays(JSON.stringify({ n: 50.4, s: 50.38, e: 8.08, w: 8.06 })));
  assert.deepStrictEqual(ways, [{ k: 'track', g: [8.065, 50.385, 8.07, 50.39] }]);

  // zweiter Abgleich: frisch und abgedeckt → keine neue Abfrage; pbfForce → doch
  let n0 = calls.length; await osm._osmSync(...box, false); assert.strictEqual(calls.length, n0, 'frisch: nichts geladen');
  osm.pbfForce(); await osm._osmSync(...box, false); assert.ok(calls.length > n0, 'pbfForce lädt neu');

  // ---------- Antippen: Leitung in der Nähe (aus dem Speicher) ----------
  events.length = 0;
  osm.powerInfo(50.3802, 8.0602); await new Promise(r => setTimeout(r, 20));
  const pe = events.find(e => e.includes('onPowerInfo'));
  const pr = JSON.parse(JSON.parse(pe.slice(pe.indexOf('(', pe.indexOf('onPowerInfo(')) + 1, pe.lastIndexOf(')'))));
  assert.ok(pr.ok && pr.cached && pr.elements.some(e => e.type === 'way' && e.tags.operator === 'Westnetz') && pr.elements.some(e => e.id === 2001), 'Leitung + Mast gefunden');
  events.length = 0;
  osm.powerInfo(52.5, 13.4); await new Promise(r => setTimeout(r, 20));   // außerhalb: online abfragen
  assert.ok(events.some(e => e.includes('onPowerInfo') && e.includes('elements')), 'online abgefragt');

  // ---------- Orte ----------
  await osm._placeSync(...box, false);
  assert.ok(had('onPlaces'));
  assert.deepStrictEqual(JSON.parse(osm.places()), [{ n: 'Limburg an der Lahn', t: 'town', lat: 50.38331, lon: 8.06671 }]);

  // ---------- Flugplätze ----------
  await osm._airfieldSync(50.45, 50.1, 8.75, 8.0, false);
  assert.ok(had('onAirfields'));
  const af = JSON.parse(osm.airfields());
  assert.ok(af.fetched > 0);
  const elz = af.list.find(a => a.icao === 'EDFZ');
  assert.strictEqual(elz.kind, 'aerodrome'); assert.strictEqual(elz.id, 'way/8001'); assert.strictEqual(elz.rth, false);
  assert.deepStrictEqual(elz.freqs, [{ type: 'INFO', desc: 'Elz Info', mhz: '122.000' }]);
  assert.ok(!af.list.some(a => a.id === 'node/8002'), 'Helipad auf dem Flugplatz entfällt');
  const ls = af.list.find(a => a.id === 'node/8003');
  assert.ok(ls.rth === true && ls.kind === 'heliport');
  const fra = af.list.find(a => a.id === 'node/8004');
  assert.strictEqual(fra.name, 'Christoph 2 – Frankfurt am Main (Uniklinik Frankfurt)'); assert.strictEqual(fra.src, 'RTH'); assert.strictEqual(fra.operator, 'BMI');
  assert.ok(af.list.some(a => a.src === 'OurAirports') || true);
  for (const a of af.list) for (const k of ['id', 'name', 'icao', 'kind', 'type', 'ele', 'phone', 'website', 'operator', 'lat', 'lon', 'freqs']) assert.ok(k in a, k + ' fehlt bei ' + a.id);

  // ---------- Geländehöhen ----------
  assert.strictEqual(osm.elevAt(50.38, 8.06), '');
  osm.elevPrefetch(JSON.stringify([[50.38, 8.06], [50.39, 8.07]])); await new Promise(r => setTimeout(r, 20));
  assert.strictEqual(osm.elevAt(50.38, 8.06), '118'); assert.strictEqual(osm.elevAt(50.383, 8.062), '118', 'Umkreis ~1 km');

  // ---------- Marktstammdatenregister ----------
  events.length = 0;
  osm.mastrSync(JSON.stringify({ states: [1405], box: [7.9, 50.3, 8.2, 50.5] })); await new Promise(r => setTimeout(r, 20));
  assert.ok(events.some(e => e.includes('onMastr') && e.includes('\\"ok\\":true')));
  const mw = JSON.parse(osm.mastrWind());
  assert.strictEqual(mw.list.length, 1, 'geplante weggelassen');
  assert.deepStrictEqual(mw.list[0], [50.41, 8.0, 141, 116.8, 199.4, 'Elzer Berg · E6', 'Privatperson', 'Elz', 'SEE1', 1, 4711, 3000]);

  // ---------- DULV ----------
  events.length = 0;
  await osm._dulvSync(true);
  assert.ok(had('onDulv'));
  const dv = JSON.parse(osm.dulv());
  assert.strictEqual(dv.complete, true); assert.strictEqual(dv.list.length, 1, 'nur deutsche PLZ');
  const d = dv.list[0];
  assert.strictEqual(d.name, 'Elz-Malmeneich'); assert.strictEqual(d.icao, 'EDFZ'); assert.strictEqual(d.zeiten, 'nach PPR – Fläche');
  assert.ok(Math.abs(d.lat - 50.416667) < 1e-5 && Math.abs(d.lon - 8.01) < 1e-5, 'Koordinaten ' + d.lat + ',' + d.lon);

  console.log('osm.test.js: alles ok (' + calls.length + ' Abrufe, Overpass-Ausweich nach 504 genutzt)');
  fs.rmSync(dir, { recursive: true, force: true });
})().catch(e => { console.error(e); process.exit(1); });
