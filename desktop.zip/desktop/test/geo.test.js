'use strict';
// Test für lib/geo.js ohne Internet: ctx.fetch wird durch Attrappen ersetzt.  Aufruf: node test/geo.test.js
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { makeCtx } = require('../lib/ctx');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'krgeo-'));
const events = [];
const ctx = makeCtx(dir, code => events.push(code));
const calls = [];
const resp = (status, body, type) => ({
  status, ok: status >= 200 && status < 300,
  headers: { get: k => (k.toLowerCase() === 'content-type' ? type || 'application/json' : null) },
  text: async () => (Buffer.isBuffer(body) ? body.toString('utf8') : String(body)),
  arrayBuffer: async () => { const b = Buffer.isBuffer(body) ? body : Buffer.from(String(body)); return b.buffer.slice(b.byteOffset, b.byteOffset + b.length); }
});
const sq = (x0, y0, d = 0.01) => ({ type: 'Polygon', coordinates: [[[x0, y0], [x0 + d, y0], [x0 + d, y0 + d], [x0, y0 + d], [x0, y0]]] });

let geoMod;   // für PNG-Testbilder
let failLayer = 'kraftwerke';
ctx.fetch = async (url, opts = {}) => {
  calls.push(url);
  const u = new URL(url);
  if (u.hostname === 'uas-betrieb.de' && u.pathname.endsWith('/wfs')) {
    const tn = u.searchParams.get('typeName') || '';
    if (tn === 'dipul:' + failLayer) return resp(503, 'down');
    if (tn.includes('temporaere_betriebseinschraenkungen')) return resp(200, JSON.stringify({ type: 'FeatureCollection', features: [{ id: tn + '.1', properties: { name: 'TBE' }, geometry: sq(8.1, 50.4) }] }));
    if (url.includes('maxFeatures=200')) return resp(200, JSON.stringify({ features: [{ id: 'naturschutzgebiete.7', properties: { name: 'NSG X' }, geometry: sq(8.0, 50.3) }] }));
    const layer = tn.replace('dipul:', '');
    return resp(200, JSON.stringify({ type: 'FeatureCollection', features: [{ id: layer + '.1', properties: { name: layer + ' A', lower_limit_altitude: 0 }, geometry: sq(8.0123456789, 50.3123456789) }] }));
  }
  if (u.hostname === 'uas-betrieb.de' && u.pathname.endsWith('/wms')) {
    // rotes bzw. blaues 256er-PNG je Gruppe
    const red = u.searchParams.get('layers').includes('flughaefen');
    const img = { w: 256, h: 256, data: Buffer.alloc(256 * 256 * 4) };
    for (let i = 0; i < 256 * 256; i++) { const x = i % 256; if (red ? x < 128 : x >= 128) { img.data[i * 4] = red ? 255 : 0; img.data[i * 4 + 2] = red ? 0 : 255; img.data[i * 4 + 3] = 200; } }
    return resp(200, geoMod._png.encode(img), 'image/png');
  }
  if (u.hostname === 'uas-betrieb.dfs.de') return resp(200, JSON.stringify({ token: 'T', expiration: Date.now() + 600000 }));
  if (u.hostname === 'dipul-service.dfs.de') {
    assert.strictEqual(opts.headers.Authorization, 'Bearer T');
    return resp(200, JSON.stringify({ affectedAreas: [{ id: 'A1', name: 'NOTAM-Gebiet' }] }));
  }
  if (u.hostname === 'sgx.geodatenzentrum.de' && u.pathname === '/wfs_vg2500') {
    const t = u.searchParams.get('TYPENAMES');
    if (t === 'vg2500_lan') return resp(200, JSON.stringify({ features: [
      { properties: { GEN: 'Hessen', RS: '06' }, geometry: { type: 'Polygon', coordinates: [[[7.7, 49.4], [10.3, 49.4], [10.3, 51.7], [7.7, 51.7], [7.7, 49.4]]] } },
      { properties: { GEN: 'Bayern', RS: '09' }, geometry: { type: 'Polygon', coordinates: [[[10.3, 47.2], [13.9, 47.2], [13.9, 50.6], [10.3, 50.6], [10.3, 47.2]]] } }] }));
    return resp(200, JSON.stringify({ features: [{ properties: { GEN: 'Gießen', RS: '065' }, geometry: { type: 'Polygon', coordinates: [[[7.9, 50.2], [9.5, 50.2], [9.5, 51.0], [7.9, 51.0], [7.9, 50.2]]] } }] }));
  }
  if (u.hostname === 'www.dhv.de') {
    if (u.pathname.endsWith('.kml')) return resp(200, '<?xml version="1.0"?><kml xmlns="x"><Placemark><coordinates>8,50 9,50 9,51</coordinates></Placemark>' + ' '.repeat(600) + '</kml>', 'application/xml');
    return resp(200, '<a href="/media/LFA2026.kml">LFA</a>', 'text/html');
  }
  if (u.hostname === 'www.gds-srv.hessen.de' || u.hostname === 'geo4.service24.rlp.de') {
    const img = { w: 256, h: 256, data: Buffer.alloc(256 * 256 * 4) };
    const he = u.hostname.includes('hessen');
    for (let i = 0; i < 256 * 256; i++) { const y = Math.floor(i / 256); if (he ? y < 128 : true) { img.data[i * 4 + 1] = he ? 150 : 90; img.data[i * 4 + 3] = 255; } }
    return resp(200, geoMod._png.encode(img), 'image/png');
  }
  if (u.hostname === 'server.arcgisonline.com') return resp(200, Buffer.from([0xff, 0xd8, 0xff, 0xe0]), 'image/jpeg');
  return resp(404, 'unbekannt ' + url);
};

const osmCalls = [];
ctx.api = {
  isOnline: async () => true,
  _osmSync: async (...a) => { osmCalls.push(['osm', ...a]); },
  _placeSync: async (...a) => { osmCalls.push(['place', ...a]); },
  _airfieldSync: async (...a) => { osmCalls.push(['af', ...a]); },
  _dulvSync: (...a) => { osmCalls.push(['dulv', ...a]); }
};
geoMod = require('../lib/geo')(ctx);
Object.assign(ctx.api, geoMod);
const tiles = geoMod.__tiles;
const wait = async (pred, ms = 8000) => { const t0 = Date.now(); while (!pred()) { if (Date.now() - t0 > ms) throw new Error('Zeitüberschreitung'); await new Promise(r => setTimeout(r, 20)); } };
const evOf = (fn) => events.filter(e => e.startsWith('window.' + fn)).map(e => JSON.parse(JSON.parse(e.slice(e.indexOf('(', e.indexOf(fn)) + 1, -1))));

(async () => {
  // ---------- PNG-Codec Rundreise ----------
  const img = { w: 3, h: 2, data: Buffer.from([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]) };
  const back = geoMod._png.decode(geoMod._png.encode(img));
  assert.deepStrictEqual([back.w, back.h, [...back.data]], [3, 2, [...img.data]]);

  // ---------- geoSync ----------
  geoMod.geoSync(JSON.stringify({ n: 50.5, s: 50.3, e: 8.3, w: 8.0, vec: { n: 50.6, s: 50.2, e: 8.4, w: 7.9 } }), false);
  await wait(() => evOf('onGeo').some(e => e.type === 'done' || e.type === 'error'), 30000);
  const done = evOf('onGeo').find(e => e.type === 'done');
  assert.ok(done, 'done-Ereignis');
  assert.strictEqual(done.ok, 30); assert.strictEqual(done.fail, 1); assert.strictEqual(done.tiles, 30);
  assert.ok(evOf('onGeo').filter(e => e.type === 'progress').length === 31, '31 Fortschritts-Ereignisse');
  // kraftwerke: 3 Versuche + 1 kleiner Versuch (mit Pausen 3 s + 6 s)
  assert.strictEqual(calls.filter(c => c.includes('typeName=dipul:kraftwerke')).length, 4);
  // Wohngrundstücke nur im engeren Gebiet, die anderen im großen Gebiet
  assert.ok(calls.find(c => c.includes('dipul:wohngrundstuecke')).includes('bbox=8.000000,50.300000,8.300000,50.500000,EPSG:4326'));
  assert.ok(calls.find(c => c.includes('dipul:flughaefen')).includes('bbox=7.900000,50.200000,8.400000,50.600000,EPSG:4326'));
  // Datei mit 5 Nachkommastellen
  const layerTxt = geoMod.geoVectorLayer('flughaefen');
  assert.ok(layerTxt.includes('8.01234') && !layerTxt.includes('8.012345'), 'gerundet');
  const arr = JSON.parse(layerTxt); assert.strictEqual(arr[0].geometry.type, 'Polygon');
  assert.strictEqual(geoMod.geoVectorLayer('kraftwerke'), '', 'fehlende Ebene → leer');
  const all = JSON.parse(geoMod.geoVectors()); assert.strictEqual(Object.keys(all).length, 30);
  const st = JSON.parse(geoMod.geoStatus()); assert.strictEqual(st.tiles, 30); assert.ok(st.fetched > 0); assert.strictEqual(st.running, false);
  assert.ok(JSON.parse(ctx.prefs.get('geo_vec_bbox')).n === 50.6);
  // Nebenaufträge: Regionen, OSM, Orte, Flugplätze, DULV, NOTAMs
  await wait(() => events.some(e => e.startsWith('window.onAirfields')));
  assert.deepStrictEqual(osmCalls.map(c => c[0]), ['osm', 'place', 'af', 'dulv']);
  assert.deepStrictEqual(osmCalls[0].slice(1), [50.5, 50.3, 8.3, 8.0, false]);
  const reg = JSON.parse(geoMod.regions());
  assert.ok(reg.fetched > 0);
  const he = reg.list.find(r => r.code === 'DE-HE'); assert.ok(he && he.refIn === true && he.src === 'BKG' && he.lvl === '4');
  const gi = reg.list.find(r => r.lvl === '5'); assert.strictEqual(gi.name, 'Regierungsbezirk Gießen');
  assert.ok(!reg.list.find(r => r.code === 'DE-BY'), 'Bayern weit weg, ohne Grenze im Gebiet');
  const no = JSON.parse(geoMod.notams());
  assert.strictEqual(no.data.src, 'api'); assert.strictEqual(no.data.areas[0].id, 'A1');
  assert.strictEqual(no.data.wfs.temporaere_betriebseinschraenkungen.length, 1);
  assert.ok(geoMod.lfa().includes('<coordinates>'));
  assert.ok(events.some(e => e.startsWith('window.onRegions')) && events.some(e => e.startsWith('window.onNotams')) && events.some(e => e.startsWith('window.onOsmLines')));

  // zweiter Aufruf im gespeicherten Gebiet → sofort done ok:0 ohne Abruf
  const before = calls.length; events.length = 0;
  geoMod.geoSync(JSON.stringify({ n: 50.5, s: 50.3, e: 8.3, w: 8.0, onlyZones: true }), false);
  await wait(() => evOf('onGeo').some(e => e.type === 'done'));
  assert.strictEqual(evOf('onGeo')[0].ok, 0); assert.strictEqual(calls.length, before);

  // ---------- geoInfo ----------
  events.length = 0;
  geoMod.geoInfo(50.305, 8.005, JSON.stringify(['naturschutzgebiete', 'flughaefen']));
  await wait(() => evOf('onGeoInfo').length);
  const gInfo = evOf('onGeoInfo')[0];
  assert.strictEqual(gInfo.ok, true); assert.strictEqual(gInfo.src, 'wfs');
  assert.strictEqual(gInfo.features[0].layer, 'naturschutzgebiete'); assert.ok(gInfo.features[0].geometry);
  assert.ok(calls[calls.length - 1].includes('typeName=' + encodeURIComponent('dipul:naturschutzgebiete,dipul:flughaefen')));

  // ---------- Kacheln ----------
  const t1 = await tiles['dipul.local'](['14', '8600', '5500'], new URLSearchParams('g=luft'));
  assert.strictEqual(t1.type, 'image/png'); assert.strictEqual(t1.cache, false);
  const wmsUrl = calls[calls.length - 1];
  assert.ok(wmsUrl.startsWith('https://uas-betrieb.de/geoservices/dipul/wms?service=WMS&version=1.1.1&request=GetMap'));
  assert.ok(wmsUrl.includes('&srs=EPSG:3857&width=256&height=256') && wmsUrl.includes('layers=' + encodeURIComponent('dipul:flughaefen,dipul:flugplaetze,dipul:kontrollzonen,dipul:flugbeschraenkungsgebiete,dipul:modellflugplaetze')));
  // bbox Web-Mercator für z14 x8600 y5500
  const R = 20037508.342789244, sz = 2 * R / 16384, minx = -R + 8600 * sz, maxy = R - 5500 * sz;
  assert.ok(wmsUrl.includes('bbox=' + [minx, maxy - sz, minx + sz, maxy].map(v => v.toFixed(3)).join(',')));
  // gespeichert → zweiter Abruf ohne Netz
  const n1 = calls.length; await tiles['dipul.local'](['14', '8600', '5500'], new URLSearchParams('g=luft')); assert.strictEqual(calls.length, n1);
  // kombiniert: luft (links rot) + energie (rechts blau)
  const tc = await tiles['dipul.local'](['14', '8600', '5500'], new URLSearchParams('g=energie,luft'));
  const ci = geoMod._png.decode(tc.body);
  assert.ok(ci.data[(10 * 256 + 10) * 4] === 255 && ci.data[(10 * 256 + 10) * 4 + 3] === 200, 'links rot');
  assert.ok(ci.data[(10 * 256 + 200) * 4 + 2] === 255, 'rechts blau');
  assert.ok(fs.existsSync(path.join(dir, 'Geozonen/Kacheln/dipul/c/energie+luft/14/8600/5500.png')));
  // dipulPixel: Punkt im linken Bereich der Kachel z14/8600/5500
  const N = 16384 * 256, X = (8600 * 256 + 20) / N, Y = (5500 * 256 + 20) / N;
  const lon = X * 360 - 180, lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * Y))) * 180 / Math.PI;
  const px = JSON.parse(geoMod.dipulPixel(lat, lon, 'luft,energie,natur'));
  assert.deepStrictEqual(px.hit, ['luft']); assert.deepStrictEqual(px.have, ['luft', 'energie']); assert.strictEqual(px.z, 14);
  geoMod.dipulClear();
  assert.ok(!fs.existsSync(path.join(dir, 'Geozonen/Kacheln/dipul')));
  // ungültige Gruppe
  assert.strictEqual(await tiles['dipul.local'](['14', '1', '1'], new URLSearchParams('g=quatsch')), null);
  // Luftbild: beide Länder → zusammengesetzt, nur HE → Original, nichts → Esri
  const d2 = await tiles['dop.local'](['15', '17200', '11000'], new URLSearchParams('s=HE,RP'));
  assert.strictEqual(d2.type, 'image/png'); assert.notStrictEqual(d2.cache, false);
  const dimg = geoMod._png.decode(d2.body);
  assert.strictEqual(dimg.data[(10 * 256 + 5) * 4 + 1], 150, 'oben HE'); assert.strictEqual(dimg.data[(200 * 256 + 5) * 4 + 1], 90, 'unten RP');
  const d1 = await tiles['dop.local'](['15', '17200', '11000'], new URLSearchParams('s=HE'));
  assert.ok(calls[calls.length - 1].includes('gds-srv.hessen.de') && calls[calls.length - 1].includes('&BBOX='));
  assert.strictEqual(d1.type, 'image/png');

  // ---------- notamSync mit Fallback auf WFS ----------
  events.length = 0;
  const realFetch = ctx.fetch;
  ctx.fetch = async (url, o) => (url.includes('dipul-service') ? resp(500, 'x') : realFetch(url, o));
  geoMod.notamSync(true);
  await wait(() => events.some(e => e.startsWith('window.onNotams')));
  const no2 = JSON.parse(geoMod.notams());
  assert.ok(no2.data.temporaere_betriebseinschraenkungen && !no2.data.src, 'WFS-Ersatz');
  assert.strictEqual(no2.err, '');

  // ---------- offline ----------
  ctx.api.isOnline = async () => false; events.length = 0;
  geoMod.geoSync(JSON.stringify({ n: 1, s: 0, e: 1, w: 0 }), true);
  await wait(() => evOf('onGeo').length);
  assert.strictEqual(evOf('onGeo')[0].type, 'offline');

  console.log('geo.test.js: alle Prüfungen bestanden');
  fs.rmSync(dir, { recursive: true, force: true });
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
