'use strict';
// Führt alle Selbsttests der Server-Module aus (ohne Internet, mit nachgebauten Antworten)
const { execFileSync } = require('child_process');
const fs = require('fs'), path = require('path');
let bad = 0;
for (const f of fs.readdirSync(__dirname).filter(f => f.endsWith('.test.js')).sort()) {
  try { execFileSync(process.execPath, [path.join(__dirname, f)], { stdio: 'inherit' }); console.log('✓ ' + f); }
  catch (e) { bad++; console.error('✗ ' + f); }
}
process.exit(bad ? 1 : 0);
