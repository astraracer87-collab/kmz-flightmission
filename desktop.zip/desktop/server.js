'use strict';
/**
 * Mission Kitzrettung – Desktop-Server.
 * Liefert index.html aus und ersetzt die Android-Brücke (window.Android) durch HTTP-Aufrufe:
 *   POST /api/call   {fn, args}  → {r} bzw. {e}      (synchron aus der Seite per XHR, wie die Java-Brücke)
 *   GET  /api/events             → Server-Sent Events: JS-Code, den die Seite ausführt (wie js(...) in Java)
 *   GET  /t/<host>/<pfad>        → Kartenbilder: Proxy + Zwischenspeicher (gleicher Ursprung → Karte als PNG speicherbar)
 * Lauscht nur auf 127.0.0.1 und verlangt ein Zufalls-Token – andere Webseiten im Browser kommen nicht an die API.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { makeCtx } = require('./lib/ctx');

const TILE_HOSTS = new Set(['sgx.geodatenzentrum.de', 'server.arcgisonline.com', 'maptool-dipul.dfs.de', 'uas-betrieb.de']);
const TILE_FRESH = 30 * 24 * 3600 * 1000;
const TILE_LIMIT = 10 * 1024 ** 3;   // Kartenspeicher am PC: bis 10 GB – alles, wo man einmal war, lädt danach sofort

function start(opts = {}) {
  const appDir = opts.appDir || path.join(__dirname, 'app');
  const dataDir = opts.dataDir || path.join(require('os').homedir(), 'Mission Kitzrettung');
  const token = opts.token || crypto.randomBytes(18).toString('hex');
  const clients = new Set();
  const pending = [];   // Ereignisse, bevor die Seite verbunden ist
  const emit = code => {
    const msg = 'data: ' + JSON.stringify(code) + '\n\n';
    if (!clients.size) { pending.push(msg); if (pending.length > 200) pending.shift(); return; }
    for (const c of clients) c.write(msg);
  };
  const ctx = makeCtx(dataDir, emit, opts.sharedFile);

  // Module laden: jedes liefert Funktionen mit den Namen der Java-Brücke
  const api = {};
  const libDir = path.join(__dirname, 'lib');
  const tileHandlers = {};   // { 'dipul.local': async (pathParts, query) => {type, body, cache?} } – von den Modulen über __tiles
  ctx.api = api;             // Module rufen sich gegenseitig über ctx.api.name(...) auf (z. B. geoSync → osmSync)
  for (const f of fs.readdirSync(libDir).sort()) {
    if (!f.endsWith('.js') || f === 'ctx.js') continue;
    try {
      const m = require(path.join(libDir, f))(ctx);
      if (m.__tiles) { Object.assign(tileHandlers, m.__tiles); delete m.__tiles; }
      Object.assign(api, m);
    } catch (e) { console.error('Modul ' + f + ' konnte nicht geladen werden:', e); }
  }

  // ---- Kartenspeicher: wächst mit dem, was angesehen wird; über dem Limit fallen die am längsten nicht genutzten Kacheln weg ----
  const tileDir = path.join(dataDir, 'kacheln');
  let tileBytes = 0;
  function tileScan(prune) {
    const all = [];
    try { for (const d of fs.readdirSync(tileDir)) { const dd = path.join(tileDir, d);
      try { for (const f of fs.readdirSync(dd)) { try { const st = fs.statSync(path.join(dd, f)); all.push([path.join(dd, f), st.size, Math.max(st.atimeMs, st.mtimeMs)]); } catch (e) { } } } catch (e) { } } } catch (e) { }
    tileBytes = all.reduce((a, x) => a + x[1], 0);
    if (prune && tileBytes > TILE_LIMIT) {
      all.sort((a, b) => a[2] - b[2]);
      for (const [f, sz] of all) { if (tileBytes <= TILE_LIMIT * 0.85) break; try { fs.unlinkSync(f); tileBytes -= sz; } catch (e) { } }
    }
  }
  setTimeout(() => tileScan(true), 5000).unref();
  setInterval(() => tileScan(true), 3600 * 1000).unref();
  api.tileCacheInfo = () => String(tileBytes);
  // E-Mail-Entwurf mit Kartenbild als Anhang: .eml mit „X-Unsent: 1“ – Outlook/Windows-Mail öffnen das als neue, sendefertige E-Mail
  api.mailDraft = json => {
    try {
      const o = JSON.parse(json), bnd = 'KR' + crypto.randomBytes(8).toString('hex');
      const enc = t => '=?UTF-8?B?' + Buffer.from(String(t), 'utf8').toString('base64') + '?=';
      const b64 = (buf) => buf.toString('base64').replace(/.{76}/g, '$&\r\n');
      const fname = String(o.fname || 'Karte').replace(/[\\/:*?"<>|]/g, '_') + '.png';
      const eml = ['To: ' + String(o.to || '').replace(/[\r\n]/g, ''), 'Subject: ' + enc(o.subject || ''), 'X-Unsent: 1', 'MIME-Version: 1.0',
        `Content-Type: multipart/mixed; boundary="${bnd}"`, '', `--${bnd}`, 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '',
        b64(Buffer.from(String(o.body || '').replace(/\r?\n/g, '\r\n'), 'utf8')), '',
        `--${bnd}`, `Content-Type: image/png; name="${enc(fname)}"`, 'Content-Transfer-Encoding: base64', `Content-Disposition: attachment; filename="${enc(fname)}"`, '',
        b64(Buffer.from(String(o.png || ''), 'base64')), '', `--${bnd}--`, ''].join('\r\n');
      const dir = path.join(dataDir, 'E-Mail-Entwürfe'); fs.mkdirSync(dir, { recursive: true });
      const f = path.join(dir, fname.replace(/\.png$/, '') + ' ' + Date.now().toString(36) + '.eml');
      fs.writeFileSync(f, eml);
      let shell = null; try { shell = require('electron').shell; } catch (e) { }
      if (!shell) return JSON.stringify({ ok: false, file: f, error: 'kein Mailprogramm erreichbar' });
      shell.openPath(f).then(err => { if (err) ctx.js(`window.onMailDraftFail && window.onMailDraftFail(${JSON.stringify(err)})`); });
      return JSON.stringify({ ok: true, file: f });
    } catch (e) { return JSON.stringify({ ok: false, error: e.message }); }
  };
  // Pilotenbriefing: HTML in einem unsichtbaren Fenster als A4-PDF drucken, in Dokumente › Mission Kitzrettung › Pilotenbriefings speichern und öffnen
  api.briefingPdf = json => {
    let el = null; try { el = require('electron'); } catch (e) { }
    if (!el || !el.BrowserWindow) return JSON.stringify({ ok: false, error: 'nur im Desktop-Programm' });
    try {
      const o = JSON.parse(json), name = String(o.name || 'Pilotenbriefing').replace(/[\\/:*?"<>|]/g, '_');
      let dir; try { dir = path.join(el.app.getPath('documents'), 'Mission Kitzrettung', 'Pilotenbriefings'); fs.mkdirSync(dir, { recursive: true }); } catch (e) { dir = path.join(dataDir, 'Pilotenbriefings'); fs.mkdirSync(dir, { recursive: true }); }
      const tmp = path.join(dataDir, 'briefing-tmp.html'); fs.writeFileSync(tmp, String(o.html || ''));
      const w = new el.BrowserWindow({ show: false, width: 820, height: 1160, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } });
      const done = r => { try { w.destroy(); } catch (e) { } try { fs.unlinkSync(tmp); } catch (e) { } ctx.js(`window.onBriefingPdf && window.onBriefingPdf(${JSON.stringify(r)})`); };
      w.loadFile(tmp)
        .then(() => new Promise(r => setTimeout(r, 800)))   // Bilder laden, Seiten einpassen
        .then(() => w.webContents.printToPDF({ pageSize: 'A4', printBackground: true, preferCSSPageSize: true }))
        .then(buf => { const f = path.join(dir, name + '.pdf'); fs.writeFileSync(f, buf); el.shell.openPath(f); done({ ok: true, file: f }); })
        .catch(e => done({ ok: false, error: e.message }));
      return JSON.stringify({ ok: true, pending: true });
    } catch (e) { return JSON.stringify({ ok: false, error: e.message }); }
  };
  api.sharedFileInfo = () => ctx.sharedFile;
  api.sharedExport = () => ctx.sharedExport();
  api.sharedImport = txt => { try { return JSON.stringify({ ok: true, n: ctx.sharedImport(txt) }); } catch (e) { return JSON.stringify({ ok: false, error: 'Datei nicht lesbar: ' + e.message }); } };
  api.sharedFileShow = () => { try { require('electron').shell.showItemInFolder(ctx.sharedFile); } catch (e) { } };
  api.tileCacheClear = () => { try { fs.rmSync(tileDir, { recursive: true, force: true }); } catch (e) { } tileBytes = 0; };

  function readIndex() {
    let html = fs.readFileSync(path.join(appDir, 'index.html'), 'utf8');
    const inj = `<script>window.KR_TOKEN=${JSON.stringify(token)};</script><script src="/bridge.js"></script>`;
    const i = html.indexOf('<script');
    return i >= 0 ? html.slice(0, i) + inj + html.slice(i) : html + inj;
  }

  function send(res, code, type, body, extra) {
    res.writeHead(code, Object.assign({ 'Content-Type': type, 'Cache-Control': 'no-store' }, extra || {}));
    res.end(body);
  }

  const busyN = {}, waitQ = {};
  const slot = h => (busyN[h] || 0) < 6 ? (busyN[h] = (busyN[h] || 0) + 1, Promise.resolve()) : new Promise(res => (waitQ[h] = waitQ[h] || []).push(res));
  const unslot = h => { const q = waitQ[h]; if (q && q.length) q.shift()(); else busyN[h] = Math.max(0, (busyN[h] || 1) - 1); };
  // Eine Kachel holen: aus dem Speicher (frisch) oder vom Server – Ergebnis { type, body } oder { status, msg }
  async function getTile(host, rest, query) {
    const key = crypto.createHash('sha1').update(host + '/' + rest + '?' + query).digest('hex');
    const dir = path.join(dataDir, 'kacheln', key.slice(0, 2)), f = path.join(dir, key);
    try {
      const st = fs.statSync(f);
      if (st.size > 0 && Date.now() - st.mtimeMs < TILE_FRESH) {
        try { const t = new Date(); fs.utimesSync(f, t, st.mtime); } catch (e) { }   // zuletzt genutzt (fürs Aufräumen)
        const b = fs.readFileSync(f), type = b[0] === 0x89 ? 'image/png' : b[0] === 0xff ? 'image/jpeg' : 'application/octet-stream';
        return { type, body: b, hit: true };
      }
    } catch (e) { }
    try {
      let r;
      if (tileHandlers[host]) r = await tileHandlers[host](rest.split('/'), new URLSearchParams(query));
      else if (TILE_HOSTS.has(host)) {
        const u = 'https://' + host + '/' + rest + (query ? '?' + query : '');
        // höchstens 6 gleichzeitig je Kartendienst, bei Überlastung (429/5xx) kurz warten und 1× neu versuchen –
        // basemap.de lehnt viele parallele Abrufe ab, dann fehlten im Kartenbild ganze Bereiche
        let resp = null, lastSt = 502;
        for (let k = 0; k < 2; k++) {
          await slot(host);
          let net = false;
          try { resp = await ctx.fetch(u, { timeout: 12000 }); } catch (e) { resp = null; net = true; } finally { unslot(host); }
          if (resp && resp.ok) break;
          if (net) throw new Error('offline');   // kein Netz: sofort alte Kachel bzw. Fehler (nicht warten)
          lastSt = resp.status; if (!(lastSt === 429 || lastSt >= 500)) break;   // nur bei Überlastung neu versuchen
          resp = null; await new Promise(res => setTimeout(res, 300 + Math.random() * 300));
        }
        if (!resp || !resp.ok) return { status: lastSt, msg: 'HTTP ' + lastSt };
        r = { type: resp.headers.get('content-type') || 'image/png', body: Buffer.from(await resp.arrayBuffer()) };
      } else return { status: 403, msg: 'Host nicht erlaubt' };
      if (!r || !r.body) return { status: 404, msg: 'leer' };
      if (r.cache !== false) { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(f, r.body); tileBytes += r.body.length;
        if (r.maxAge) try { const t = new Date(Date.now() - TILE_FRESH + r.maxAge * 1000); fs.utimesSync(f, new Date(), t); } catch (e) { } }   // Google: nur so lange wie erlaubt
      return { type: r.type || 'image/png', body: r.body };
    } catch (e) {
      if (host !== 'google.sat') try { return { type: 'image/png', body: fs.readFileSync(f), stale: true }; } catch (e2) { }   // offline: alte Kachel besser als keine
      return { status: 502, msg: 'nicht erreichbar' };
    }
  }
  async function tile(req, res, host, rest, query) {
    const r = await getTile(host, rest, query);
    if (r.body) return send(res, 200, r.type, r.body, { 'Cache-Control': 'max-age=86400' });
    send(res, r.status || 502, 'text/plain', r.msg || 'Fehler');
  }
  // Viele Kacheln auf einmal in den Speicher holen (Kartenbilder, Briefing): der Browser lädt nur ~6 gleichzeitig vom Programm –
  // beim Bild mit 40 Kacheln liefen dabei Wartezeiten ab und Kacheln fehlten. Hier holt das Programm sie parallel, danach kommen sie sofort aus dem Speicher.
  async function tileBatch(urls) {
    const list = [...new Set((Array.isArray(urls) ? urls : []).map(String))].slice(0, 400);
    let i = 0, ok = 0, fail = 0; const st = {};
    const run = async () => { while (i < list.length) { const u = list[i++];
      const m = /^\/t\/([^/]+)\/([^?]*)\??(.*)$/.exec(u); if (!m) { fail++; continue; }
      try { const r = await getTile(decodeURIComponent(m[1]), m[2], m[3]); if (r.body) ok++; else { fail++; st[r.status || 0] = (st[r.status || 0] || 0) + 1; } } catch (e) { fail++; st.err = (st.err || 0) + 1; } } };
    await Promise.all(Array.from({ length: Math.min(12, list.length) }, run));
    return { ok, fail, st };
  }

  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    // DNS-Rebinding abwehren: nur direkt über 127.0.0.1/localhost
    const host = String(req.headers.host || '').replace(/:\d+$/, '');
    if (host !== '127.0.0.1' && host !== 'localhost') return send(res, 403, 'text/plain', 'verboten');
    try {
      if (u.pathname === '/' || u.pathname === '/index.html') {
        if (u.searchParams.get('t') !== token) return send(res, 403, 'text/plain', 'Bitte über das Programm „Mission Kitzrettung“ öffnen.');
        return send(res, 200, 'text/html; charset=utf-8', readIndex());
      }
      if (u.pathname === '/bridge.js') return send(res, 200, 'text/javascript; charset=utf-8', fs.readFileSync(path.join(__dirname, 'bridge.js')));
      if (u.pathname === '/tb' && req.method === 'POST') {
        let body = ''; for await (const ch of req) { body += ch; if (body.length > 400000) break; }
        let urls = []; try { urls = JSON.parse(body || '[]'); } catch (e) { }
        return send(res, 200, 'application/json', JSON.stringify(await tileBatch(urls)));
      }
      if (u.pathname.startsWith('/t/')) {
        const parts = u.pathname.slice(3).split('/'), h = decodeURIComponent(parts.shift());
        return tile(req, res, h, parts.join('/'), u.search.slice(1));
      }
      if (u.pathname.startsWith('/api/')) {
        if (req.headers['x-kr'] !== token && u.searchParams.get('t') !== token) return send(res, 403, 'text/plain', 'verboten');
        if (u.pathname === '/api/events') {
          res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
          res.write(': ok\n\n'); clients.add(res);
          while (pending.length) res.write(pending.shift());
          const ka = setInterval(() => res.write(': ka\n\n'), 20000);
          req.on('close', () => { clearInterval(ka); clients.delete(res); });
          return;
        }
        if (u.pathname === '/api/call' && req.method === 'POST') {
          let body = ''; for await (const ch of req) body += ch;
          const { fn, args } = JSON.parse(body || '{}');
          const f = String(fn).startsWith('_') ? null : api[fn];   // _name = nur intern zwischen Modulen
          if (typeof f !== 'function') return send(res, 200, 'application/json', JSON.stringify({ missing: true }));
          try {
            const r = await f(...(Array.isArray(args) ? args : []));
            return send(res, 200, 'application/json', JSON.stringify({ r: r === undefined ? null : r }));
          } catch (e) {
            console.error('Fehler in ' + fn + ':', e);
            return send(res, 200, 'application/json', JSON.stringify({ e: String(e && e.message || e) }));
          }
        }
        if (u.pathname === '/api/list') return send(res, 200, 'application/json', JSON.stringify(Object.keys(api).filter(k => !k.startsWith('_'))));
      }
      send(res, 404, 'text/plain', 'nicht gefunden');
    } catch (e) { console.error(e); send(res, 500, 'text/plain', 'Fehler'); }
  });

  return new Promise(resolve => {
    server.listen(opts.port || 0, '127.0.0.1', () => {
      const port = server.address().port;
      resolve({ server, port, token, url: `http://127.0.0.1:${port}/?t=${token}`, ctx, api, flush: () => ctx.flushPrefs && ctx.flushPrefs(), close: () => server.close() });
    });
  });
}

module.exports = { start };

// Direkt starten (ohne Electron): node server.js → Adresse im Browser öffnen
if (require.main === module) {
  const appDir = process.env.KR_APP || (fs.existsSync(path.join(__dirname, 'app', 'index.html')) ? path.join(__dirname, 'app') : path.join(__dirname, '..'));
  start({ appDir, dataDir: process.env.KR_DATA, port: +process.env.PORT || 0, token: process.env.KR_TOKEN }).then(s => console.log('Mission Kitzrettung läuft: ' + s.url));
}
