/* Mission Kitzrettung – Brücke für die Desktop-Version.
 * Stellt window.Android bereit wie die Android-App: jede Funktion ruft synchron den lokalen Server auf.
 * Es gibt nur die Funktionen, die der Server wirklich kann – index.html prüft mit `if (A.xyz)`, was verfügbar ist. */
(function () {
  'use strict';
  var T = window.KR_TOKEN || new URLSearchParams(location.search).get('t') || '';
  function call(fn, args) {
    var x = new XMLHttpRequest();
    x.open('POST', '/api/call', false);
    x.setRequestHeader('Content-Type', 'application/json');
    x.setRequestHeader('X-KR', T);
    try { x.send(JSON.stringify({ fn: fn, args: args })); } catch (e) { return undefined; }
    if (x.status !== 200) return undefined;
    var o = JSON.parse(x.responseText || '{}');
    if (o.e) { console.warn('[Brücke] ' + fn + ': ' + o.e); return undefined; }
    return o.r === null ? undefined : o.r;
  }
  var names = [];
  try {
    var x = new XMLHttpRequest(); x.open('GET', '/api/list?t=' + encodeURIComponent(T), false); x.send();
    names = JSON.parse(x.responseText || '[]');
  } catch (e) { }
  var A = {};
  names.forEach(function (n) { A[n] = function () { return call(n, Array.prototype.slice.call(arguments)); }; });
  // Platzhalter für Fernsteuerungs-Funktionen, die index.html ohne Prüfung aufruft (auf dem PC gibt es sie nicht)
  var NOOP = {
    internalRoot: function () { return ''; }, roots: function () { return '[]'; }, requestAccess: function () { }, locate: function () { },
    listDirs: function (p) { return JSON.stringify({ ok: true, path: p, parent: null, dirs: [], kmz: 0 }); },
    listKmz: function () { return JSON.stringify({ ok: true, files: [] }); }, readKml: function () { return ''; },
    transfer: function () { return JSON.stringify({ ok: false, error: 'Auf dem PC nicht verfügbar', done: 0, errors: [] }); },
    deleteKmz: function () { return JSON.stringify({ ok: false }); }, convertInPlace: function () { return JSON.stringify({ ok: false, error: 'Auf dem PC nicht verfügbar' }); },
    cacheClear: function () { }, dipulClear: function () { }, pbfForce: function () { }, prefetchCancel: function () { },
    rid: function () { return '[]'; }, ridStop: function () { }, traffic: function () { return '[]'; }, trafficStop: function () { }
  };
  Object.keys(NOOP).forEach(function (k) { if (!A[k]) A[k] = NOOP[k]; });
  // Links im Standardbrowser öffnen (Electron leitet window.open nach außen)
  A.openUrl = function (u) { window.open(u, '_blank'); };
  window.Android = A;
  window.KR_VARIANT = /^(web|lite|full)$/.test(new URLSearchParams(location.search).get('v') || '') ? new URLSearchParams(location.search).get('v') : 'web';   // ?v=lite nur zum Testen
  // Kartenbilder über den lokalen Server laden (gleicher Ursprung → Karte lässt sich als Bild speichern)
  window.KR_TILE = function (u) { return String(u).replace(/^https:\/\/([^/]+)\//, '/t/$1/'); };
  // Rückrufe des Servers (wie js(...) in der Android-App)
  function listen() {
    var es = new EventSource('/api/events?t=' + encodeURIComponent(T));
    es.onmessage = function (ev) { try { (0, eval)(JSON.parse(ev.data)); } catch (e) { console.error('[Brücke] Rückruf', e); } };
    es.onerror = function () { es.close(); setTimeout(listen, 3000); };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', listen); else listen();
})();
