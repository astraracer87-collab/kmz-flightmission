'use strict';
/** Electron-Hülle: startet den lokalen Server und zeigt die Oberfläche in einem eigenen Fenster */
const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');
const { start } = require('./server');

let win = null, srv = null;
if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

async function createWindow() {
  srv = srv || await start({ appDir: path.join(__dirname, 'app'), dataDir: path.join(app.getPath('userData'), 'daten') });
  win = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600, title: 'Mission Kitzrettung',
    icon: path.join(__dirname, 'app', 'icon.png'), backgroundColor: '#11161d',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false }
  });
  // Links (Flightradar, dipul, Dokumente, mailto:) im Standardbrowser bzw. Mailprogramm öffnen – nie im App-Fenster
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^(https?|mailto):/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(`http://127.0.0.1:${srv.port}/`)) { e.preventDefault(); if (/^(https?|mailto):/i.test(url)) shell.openExternal(url); } });
  // Dateien (Kartenbild) speichern: Standard-Dialog „Speichern unter“
  win.webContents.session.on('will-download', item => item.setSaveDialogOptions({ title: 'Bild speichern' }));
  win.loadURL(srv.url);
  win.on('closed', () => { win = null; });
}

Menu.setApplicationMenu(Menu.buildFromTemplate([
  ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
  { label: 'Datei', submenu: [{ role: 'reload', label: 'Neu laden' }, { type: 'separator' }, { role: process.platform === 'darwin' ? 'close' : 'quit', label: 'Beenden' }] },
  { label: 'Bearbeiten', submenu: [{ role: 'copy', label: 'Kopieren' }, { role: 'paste', label: 'Einfügen' }, { role: 'selectAll', label: 'Alles auswählen' }] },
  { label: 'Ansicht', submenu: [{ role: 'zoomIn', label: 'Größer' }, { role: 'zoomOut', label: 'Kleiner' }, { role: 'resetZoom', label: 'Normale Größe' }, { role: 'togglefullscreen', label: 'Vollbild' }, { role: 'toggleDevTools', label: 'Entwicklerwerkzeuge' }] }
]));

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!win) createWindow(); });
