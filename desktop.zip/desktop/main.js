'use strict';
/** Electron-Hülle: startet den lokalen Server und zeigt die Oberfläche in einem eigenen Fenster */
const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
/** Adressdatei neben dem Programm (Installationsordner bzw. Ordner der portablen .exe) – zum Weitergeben; sonst im Benutzerordner */
function sharedFile() {
  const name = 'Kitzrettung-Adressen.json';
  const dirs = [process.env.PORTABLE_EXECUTABLE_DIR, process.platform === 'darwin' ? null : (app.isPackaged ? path.dirname(process.execPath) : __dirname), path.join(app.getPath('documents'), 'Mission Kitzrettung')].filter(Boolean);
  for (const d of dirs) { try { fs.mkdirSync(d, { recursive: true }); fs.accessSync(d, fs.constants.W_OK); return path.join(d, name); } catch (e) { } }
  return path.join(app.getPath('userData'), name);
}
const { start } = require('./server');

let win = null, srv = null;
if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

async function createWindow() {
  srv = srv || await start({ appDir: path.join(__dirname, 'app'), dataDir: path.join(app.getPath('userData'), 'daten'), sharedFile: sharedFile() });
  win = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600, title: 'Mission Kitzrettung', autoHideMenuBar: true, show: false,
    icon: path.join(__dirname, 'app', 'icon.png'), backgroundColor: '#11161d',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false }
  });
  // Links (Flightradar, dipul, Dokumente, mailto:) im Standardbrowser bzw. Mailprogramm öffnen – nie im App-Fenster
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^(https?|mailto):/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(`http://127.0.0.1:${srv.port}/`)) { e.preventDefault(); if (/^(https?|mailto):/i.test(url)) shell.openExternal(url); } });
  // Dateien (Kartenbild) speichern: Standard-Dialog „Speichern unter“
  win.webContents.session.on('will-download', (event, item) => { try { item.setSaveDialogOptions({ title: 'Bild speichern', defaultPath: path.join(app.getPath('downloads'), item.getFilename()) }); } catch (e) { } });
  // Tastenkürzel ohne Menü: F5/Strg+R neu laden, F11 Vollbild, Strg +/−/0 Größe, F12 Entwicklerwerkzeuge
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    const c = i.control || i.meta, wc = win.webContents;
    if (i.key === 'F5' || (c && i.key.toLowerCase() === 'r')) { wc.reload(); e.preventDefault(); }
    else if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (i.key === 'F12') { wc.toggleDevTools(); e.preventDefault(); }
    else if (c && (i.key === '+' || i.key === '=')) { wc.setZoomLevel(wc.getZoomLevel() + 0.5); e.preventDefault(); }
    else if (c && i.key === '-') { wc.setZoomLevel(wc.getZoomLevel() - 0.5); e.preventDefault(); }
    else if (c && i.key === '0') { wc.setZoomLevel(0); e.preventDefault(); }
  });
  win.loadURL(srv.url);
  win.once('ready-to-show', () => { win.maximize(); win.show(); });   // PC: gleich groß starten
  win.on('closed', () => { win = null; });
}

// Windows: keine Menüleiste (Datei/Bearbeiten/Ansicht) – Tastenkürzel bleiben über before-input-event erhalten. Mac braucht das Menü für ⌘C/⌘V.
if (process.platform !== 'darwin') Menu.setApplicationMenu(null);
else Menu.setApplicationMenu(Menu.buildFromTemplate([
  { role: 'appMenu' },
  { label: 'Datei', submenu: [{ role: 'reload', label: 'Neu laden' }, { type: 'separator' }, { role: process.platform === 'darwin' ? 'close' : 'quit', label: 'Beenden' }] },
  { label: 'Bearbeiten', submenu: [{ role: 'copy', label: 'Kopieren' }, { role: 'paste', label: 'Einfügen' }, { role: 'selectAll', label: 'Alles auswählen' }] },
  { label: 'Ansicht', submenu: [{ role: 'zoomIn', label: 'Größer' }, { role: 'zoomOut', label: 'Kleiner' }, { role: 'resetZoom', label: 'Normale Größe' }, { role: 'togglefullscreen', label: 'Vollbild' }, { role: 'toggleDevTools', label: 'Entwicklerwerkzeuge' }] }
]));

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('will-quit', () => { try { srv && srv.flush && srv.flush(); } catch (e) { } });   // Einstellungen vor dem Beenden sicher schreiben
app.on('activate', () => { if (!win) createWindow(); });
